LINGXI REALITY OPERATING SYSTEM
=====================================

Document: phase0_readme
Version: 1.0
Status: DRAFT
Owner: Phase 0 Core ABI
Phase: Engineering Era / Phase 0
Depends: Root Constitution
Affects: P00-P07; Skills Repository; Engineering Repository
Constitution: Root Constitution; P00 Reality Constraint
Last Audit: Pending
Freeze Date: Pending

=====================================

# Phase 0 Core ABI Readme

本目录定义 Lingxi Reality Operating System 的 Kernel ABI。它不是宣传材料，不是商业说明，而是所有后续协议、技能、工程实现、商业产品的底层接口契约。

文件清单：
- P00_RealityConstraint.txt
- P01_ObservationProtocol.txt
- P02_EventProtocol.txt
- P03_NarrativeProtocol.txt
- P04_ReasoningProtocol.txt
- P05_RoomDNAProtocol.txt
- P06_DecisionProtocol.txt
- P07_VerificationProtocol.txt
- ABI_TEMPLATE_v1.1.txt
- protocol_dependency_graph.txt
- phase0_readme.txt

核心铁律：
宪法仓库定义灵犀是谁。
技能仓库定义灵犀能做什么。
运行时门禁保证：灵犀做任何事时，都不能忘记自己是谁。
当灵犀忘记自己是谁时，灵犀必须停止行动。

三条根原则：
1. 现实永远先于智能。
2. 验证永远先于学习。
3. 宪法永远先于技能。

协议拓扑：
P00 Reality Constraint → P01 Observation → P02 Event → P03 Narrative → P04 Reasoning → P05 RoomDNA → P06 Decision → P07 Verification → Correction → Reality。

使用规则：
1. 任何技能启动前必须读取并校验宪法仓库。
2. 任何协议实现必须遵守 P00。
3. 任何下游能力不得重定义上游协议。
4. 任何 Decision 必须产生 VerificationResult。
5. 任何 VerificationResult 必须可以进入 Correction 管道。
