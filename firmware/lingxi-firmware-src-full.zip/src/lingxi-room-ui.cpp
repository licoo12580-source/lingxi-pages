/**
 * 灵犀 客房显示界面 — 替换 lv_demo_widgets()
 * 
 * 用途：酒店客房内IPS屏（ILI9488 320x480）
 * 显示：房号·酒店名·入住状态·当日节能·温度·安防
 * 
 * 与 main.cpp 配合：lv_demo_widgets() → lingxi_room_ui_create()
 * 
 * 数据源：MQTT lingxi/v1/+/# 三 topic (sense/energy/system)
 *   架构：ML307C 主设备→MQTT→屏端 ESP32-S3 WiFi 订阅消费
 * 
 * 字段映射：
 *   sense  → radar_people, env_temp, env_humidity, env_light
 *   energy → power_today_total, power_current, power_voltage, power_current_a
 *   system → device_online, alarm_active, ota_version
 */


#include "lvgl.h"
#include <stdio.h>

// ========== 布局常量 ==========
#define SCREEN_W 320
#define SCREEN_H 480

// ========== 控件句柄 ==========
static lv_obj_t *label_room = NULL;     // 房号（大号）
static lv_obj_t *label_hotel = NULL;    // 酒店名
static lv_obj_t *label_status = NULL;   // 占位状态
static lv_obj_t *label_eco = NULL;      // 节能数据
static lv_obj_t *label_temp = NULL;     // 温度
static lv_obj_t *label_humid = NULL;    // 湿度值
static lv_obj_t *label_alarm = NULL;    // 安防状态
static lv_obj_t *status_indicator = NULL; // 状态圆点

// ========== 配色 ==========
#define COLOR_BG        lv_color_hex(0x0f172a)   // 深蓝黑
#define COLOR_CARD      lv_color_hex(0x1e293b)   // 卡片底
#define COLOR_ACCENT    lv_color_hex(0x3b82f6)   // 蓝色强调
#define COLOR_GREEN     lv_color_hex(0x22c55e)   // 绿色（有人/节能正）
#define COLOR_RED       lv_color_hex(0xef4444)   // 红色（告警）
#define COLOR_ORANGE    lv_color_hex(0xf59e0b)   // 橙色
#define COLOR_GRAY      lv_color_hex(0x64748b)   // 灰色（无人）
#define COLOR_WHITE     lv_color_hex(0xe2e8f0)   // 文字主色
#define COLOR_DIM       lv_color_hex(0x94a3b8)   // 次要文字

// ========== 工具函数 ==========

static lv_obj_t *create_card(lv_obj_t *parent, lv_coord_t x, lv_coord_t y,
                              lv_coord_t w, lv_coord_t h, lv_color_t bg) {
    lv_obj_t *card = lv_obj_create(parent);
    lv_obj_set_pos(card, x, y);
    lv_obj_set_size(card, w, h);
    lv_obj_set_style_bg_color(card, bg, 0);
    lv_obj_set_style_border_width(card, 0, 0);
    lv_obj_set_style_radius(card, 12, 0);
    lv_obj_set_style_pad_all(card, 0, 0);
    lv_obj_set_style_shadow_width(card, 0, 0);
    return card;
}

static lv_obj_t *create_label(lv_obj_t *parent, lv_coord_t x, lv_coord_t y,
                               lv_coord_t w, lv_coord_t h, const char *text,
                               lv_color_t color, lv_font_t *font,
                               lv_text_align_t align) {
    lv_obj_t *label = lv_label_create(parent);
    lv_obj_set_pos(label, x, y);
    lv_obj_set_size(label, w, h);
    lv_label_set_text(label, text);
    lv_obj_set_style_text_color(label, color, 0);
    lv_obj_set_style_text_align(label, align, 0);
    if (font) lv_obj_set_style_text_font(label, font, 0);
    return label;
}

// ========== 主界面创建 ==========

void lingxi_room_ui_create(void) {
    // ===== 背景 =====
    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, COLOR_BG, 0);

    // ===== 顶部：房号 + 酒店名（深色渐变条） =====
    lv_obj_t *header = lv_obj_create(scr);
    lv_obj_set_pos(header, 0, 0);
    lv_obj_set_size(header, SCREEN_W, 80);
    lv_obj_set_style_bg_color(header, lv_color_hex(0x131b32), 0);
    lv_obj_set_style_border_width(header, 0, 0);
    lv_obj_set_style_radius(header, 0, 0);
    lv_obj_set_style_shadow_width(header, 0, 0);

    // 房号（大号，暂无自定义字体，用系统默认最大）
    label_room = lv_label_create(header);
    lv_obj_set_pos(label_room, 16, 8);
    lv_obj_set_size(label_room, 200, 44);
    lv_label_set_text(label_room, "1208");
    lv_obj_set_style_text_color(label_room, COLOR_WHITE, 0);
    lv_obj_set_style_text_font(label_room, &lv_font_montserrat_48, 0);

    // 酒店名
    label_hotel = lv_label_create(header);
    lv_obj_set_pos(label_hotel, 16, 52);
    lv_obj_set_size(label_hotel, 200, 24);
    lv_label_set_text(label_hotel, "兰威酒店 · 标准大床房");
    lv_obj_set_style_text_color(label_hotel, COLOR_DIM, 0);
    lv_obj_set_style_text_font(label_hotel, &lv_font_montserrat_14, 0);

    // 状态指示灯（右上角大圆点）
    status_indicator = lv_obj_create(header);
    lv_obj_set_pos(status_indicator, SCREEN_W - 48, 20);
    lv_obj_set_size(status_indicator, 28, 28);
    lv_obj_set_style_bg_color(status_indicator, COLOR_GREEN, 0);
    lv_obj_set_style_border_width(status_indicator, 0, 0);
    lv_obj_set_style_radius(status_indicator, 14, 0);
    lv_obj_set_style_shadow_width(status_indicator, 0, 0);
    lv_obj_set_style_shadow_color(status_indicator, COLOR_GREEN, 0);
    lv_obj_set_style_shadow_opa(status_indicator, LV_OPA_40, 0);
    lv_obj_set_style_shadow_spread(status_indicator, 4, 0);

    // 状态文字
    label_status = lv_label_create(header);
    lv_obj_set_pos(label_status, SCREEN_W - 100, 52);
    lv_obj_set_size(label_status, 84, 24);
    lv_label_set_text(label_status, "有人 ♨");
    lv_obj_set_style_text_color(label_status, COLOR_GREEN, 0);
    lv_obj_set_style_text_align(label_status, LV_TEXT_ALIGN_RIGHT, 0);
    lv_obj_set_style_text_font(label_status, &lv_font_montserrat_14, 0);

    // ===== 节能卡片（主数据区） =====
    lv_obj_t *eco_card = create_card(scr, 16, 96, SCREEN_W - 32, 100, COLOR_CARD);

    lv_obj_t *eco_icon = lv_label_create(eco_card);
    lv_obj_set_pos(eco_icon, 16, 12);
    lv_obj_set_size(eco_icon, 40, 40);
    lv_label_set_text(eco_icon, "⚡");
    lv_obj_set_style_text_font(eco_icon, &lv_font_montserrat_24, 0);

    lv_obj_t *eco_title = lv_label_create(eco_card);
    lv_obj_set_pos(eco_title, 56, 14);
    lv_obj_set_size(eco_title, 120, 20);
    lv_label_set_text(eco_title, "今日节能");
    lv_obj_set_style_text_color(eco_title, COLOR_DIM, 0);
    lv_obj_set_style_text_font(eco_title, &lv_font_montserrat_14, 0);

    label_eco = lv_label_create(eco_card);
    lv_obj_set_pos(label_eco, 56, 36);
    lv_obj_set_size(label_eco, 200, 44);
    lv_label_set_text(label_eco, "2.3 kWh");
    lv_obj_set_style_text_color(label_eco, COLOR_GREEN, 0);
    lv_obj_set_style_text_font(label_eco, &lv_font_montserrat_36, 0);

    // 节能率进度条
    lv_obj_t *eco_bar = lv_bar_create(eco_card);
    lv_obj_set_pos(eco_bar, 56, 76);
    lv_obj_set_size(eco_bar, 220, 10);
    lv_obj_set_style_bg_color(eco_bar, lv_color_hex(0x1e293b), 0);
    lv_obj_set_style_border_width(eco_bar, 0, 0);
    lv_obj_set_style_radius(eco_bar, 5, 0);
    lv_bar_set_range(eco_bar, 0, 100);
    lv_bar_set_value(eco_bar, 65, LV_ANIM_ON);
    lv_obj_set_style_bg_color(eco_bar, COLOR_GREEN, LV_PART_INDICATOR);

    lv_obj_t *eco_pct = lv_label_create(eco_card);
    lv_obj_set_pos(eco_icon, 16, 76);
    lv_obj_set_size(eco_icon, 36, 12);
    lv_label_set_text(eco_pct, "65%");
    lv_obj_set_style_text_color(eco_pct, COLOR_DIM, 0);

    // ===== 环境数据行（温度 + 湿度两格） =====
    // 温度卡片
    lv_obj_t *temp_card = create_card(scr, 16, 212, (SCREEN_W - 40) / 2, 80, COLOR_CARD);
    lv_obj_t *temp_icon = lv_label_create(temp_card);
    lv_obj_set_pos(temp_icon, 12, 8);
    lv_label_set_text(temp_icon, "🌡");
    lv_obj_set_style_text_font(temp_icon, &lv_font_montserrat_20, 0);

    lv_obj_t *temp_title = lv_label_create(temp_card);
    lv_obj_set_pos(temp_title, 12, 32);
    lv_label_set_text(temp_title, "温度");
    lv_obj_set_style_text_color(temp_title, COLOR_DIM, 0);
    lv_obj_set_style_text_font(temp_title, &lv_font_montserrat_12, 0);

    label_temp = lv_label_create(temp_card);
    lv_obj_set_pos(label_temp, 12, 46);
    lv_label_set_text(label_temp, "26°C");
    lv_obj_set_style_text_color(label_temp, COLOR_WHITE, 0);
    lv_obj_set_style_text_font(label_temp, &lv_font_montserrat_24, 0);

    // 湿度卡片
    lv_obj_t *humid_card = create_card(scr, SCREEN_W / 2 + 4, 212, (SCREEN_W - 40) / 2, 80, COLOR_CARD);
    lv_obj_t *humid_icon = lv_label_create(humid_card);
    lv_obj_set_pos(humid_icon, 12, 8);
    lv_label_set_text(humid_icon, "💧");
    lv_obj_set_style_text_font(humid_icon, &lv_font_montserrat_20, 0);

    lv_obj_t *humid_title = lv_label_create(humid_card);
    lv_obj_set_pos(humid_title, 12, 32);
    lv_label_set_text(humid_title, "湿度");
    lv_obj_set_style_text_color(humid_title, COLOR_DIM, 0);
    lv_obj_set_style_text_font(humid_title, &lv_font_montserrat_12, 0);

    // 湿度值
    label_humid = lv_label_create(humid_card);
    lv_obj_set_pos(label_humid, 12, 46);
    lv_label_set_text(label_humid, "62%");
    lv_obj_set_style_text_color(label_humid, COLOR_WHITE, 0);
    lv_obj_set_style_text_font(label_humid, &lv_font_montserrat_24, 0);

    // ===== 安防状态条（底部） =====
    lv_obj_t *alarm_card = create_card(scr, 16, 308, SCREEN_W - 32, 60, COLOR_CARD);

    lv_obj_t *alarm_icon = lv_label_create(alarm_card);
    lv_obj_set_pos(alarm_icon, 16, 16);
    lv_label_set_text(alarm_icon, "🛡");
    lv_obj_set_style_text_font(alarm_icon, &lv_font_montserrat_20, 0);

    lv_obj_t *alarm_title = lv_label_create(alarm_card);
    lv_obj_set_pos(alarm_title, 52, 10);
    lv_obj_set_size(alarm_title, 100, 20);
    lv_label_set_text(alarm_title, "安防状态");
    lv_obj_set_style_text_color(alarm_title, COLOR_DIM, 0);
    lv_obj_set_style_text_font(alarm_title, &lv_font_montserrat_14, 0);

    label_alarm = lv_label_create(alarm_card);
    lv_obj_set_pos(label_alarm, 52, 30);
    lv_obj_set_size(label_alarm, 200, 24);
    lv_label_set_text(label_alarm, "✅ 一切正常 · 无人闯入");
    lv_obj_set_style_text_color(label_alarm, COLOR_GREEN, 0);
    lv_obj_set_style_text_font(label_alarm, &lv_font_montserrat_14, 0);

    // ===== 底部状态栏 =====
    lv_obj_t *footer = lv_obj_create(scr);
    lv_obj_set_pos(footer, 0, SCREEN_H - 40);
    lv_obj_set_size(footer, SCREEN_W, 40);
    lv_obj_set_style_bg_color(footer, lv_color_hex(0x0a0f1a), 0);
    lv_obj_set_style_border_width(footer, 0, 0);
    lv_obj_set_style_radius(footer, 0, 0);
    lv_obj_set_style_shadow_width(footer, 0, 0);

    // 时间（后续可通过 MQTT 更新）
    lv_obj_t *label_time = lv_label_create(footer);
    lv_obj_set_pos(label_time, 16, 8);
    lv_label_set_text(label_time, "14:30 · 2026-06-23");
    lv_obj_set_style_text_color(label_time, COLOR_DIM, 0);
    lv_obj_set_style_text_font(label_time, &lv_font_montserrat_12, 0);

    // 连接状态
    lv_obj_t *label_conn = lv_label_create(footer);
    lv_obj_set_pos(label_conn, SCREEN_W - 120, 8);
    lv_obj_set_size(label_conn, 104, 24);
    lv_label_set_text(label_conn, "📶 WiFi 在线");
    lv_obj_set_style_text_color(label_conn, COLOR_GREEN, 0);
    lv_obj_set_style_text_align(label_conn, LV_TEXT_ALIGN_RIGHT, 0);
    lv_obj_set_style_text_font(label_conn, &lv_font_montserrat_12, 0);
}

// ========== 数据更新接口 ==========
// 从 MQTT/串口/后端接收数据时调用

/**
 * 更新房间数据
 * @param room_no    房号 (e.g. "1208")
 * @param hotel      酒店名
 * @param occupied   1=有人, 0=无人
 * @param eco_kwh    今日节能 (kWh)
 * @param eco_pct    节能率 (0~100)
 * @param temp_c     室温 (°C)
 * @param humidity   湿度 (%)
 * @param alarm      0=正常, 1=告警
 * @param alarm_msg  告警信息
 * @param time_str   时间字符串
 */
void lingxi_room_ui_update(const char *room_no, const char *hotel,
                            int occupied, float eco_kwh, int eco_pct,
                            float temp_c, int humidity,
                            int alarm, const char *alarm_msg,
                            const char *time_str) {
    if (label_room) {
        lv_label_set_text(label_room, room_no ? room_no : "--");
    }
    if (label_hotel) {
        lv_label_set_text(label_hotel, hotel ? hotel : "");
    }
    if (label_status) {
        lv_label_set_text(label_status, occupied ? "有人 ♨" : "无人 💤");
        lv_obj_set_style_text_color(label_status, 
            occupied ? COLOR_GREEN : COLOR_ORANGE, 0);
    }
    if (status_indicator) {
        lv_obj_set_style_bg_color(status_indicator,
            occupied ? COLOR_GREEN : COLOR_GRAY, 0);
        lv_obj_set_style_shadow_color(status_indicator,
            occupied ? COLOR_GREEN : COLOR_GRAY, 0);
    }
    if (label_eco) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%.1f kWh", eco_kwh);
        lv_label_set_text(label_eco, buf);
    }
    if (label_temp) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%.0f°C", temp_c);
        lv_label_set_text(label_temp, buf);
    }
    if (label_humid) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d%%", humidity);
        lv_label_set_text(label_humid, buf);
    }
    if (label_alarm) {
        if (alarm) {
            lv_label_set_text(label_alarm, alarm_msg ? alarm_msg : "⚠️ 异常！");
            lv_obj_set_style_text_color(label_alarm, COLOR_RED, 0);
        } else {
            lv_label_set_text(label_alarm, "✅ 一切正常 · 无人闯入");
            lv_obj_set_style_text_color(label_alarm, COLOR_GREEN, 0);
        }
    }
}
