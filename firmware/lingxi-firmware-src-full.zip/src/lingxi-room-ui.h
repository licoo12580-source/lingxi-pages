#ifndef LINGXI_ROOM_UI_H
#define LINGXI_ROOM_UI_H

#ifdef __cplusplus
extern "C" {
#endif

// 创建主界面（替换 lv_demo_widgets()）
void lingxi_room_ui_create(void);

// 实时更新房间数据
void lingxi_room_ui_update(const char *room_no, const char *hotel,
                           int occupied, float eco_kwh, int eco_pct,
                           float temp_c, int humidity,
                           int alarm, const char *alarm_msg,
                           const char *time_str);

#ifdef __cplusplus
}
#endif

#endif // LINGXI_ROOM_UI_H
