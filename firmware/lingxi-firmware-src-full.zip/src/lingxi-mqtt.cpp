/**
 * 灵犀 屏端MQTT接收模块 — 实现
 * 
 * 架构:
 *   WiFi连接 → ESP-IDF MQTT Client → 订阅 lingxi/v1/{device_id}/#
 *   → 按 topic type 分流 (sense/energy/system)
 *   → cJSON解析 → 合并到 lingxi_state_t → lingxi_room_ui_update()
 * 
 * WiFi/代理参数在 lingxi_mqtt_init() 传入配置结构体
 * 
 * 协议版本: v2.0 — 三 topic 方案
 */

#include "lingxi-mqtt.h"
#include "lingxi-room-ui.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// ESP-IDF components (included via Arduino core)
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_mqtt_client.h"

// Arduino WiFi
#include <WiFi.h>

// ========== 日志标签 ==========
static const char *TAG = "LingxiMQTT";

// ========== 静态变量 ==========
static esp_mqtt_client_handle_t  mqtt_client   = NULL;
static esp_mqtt_client_config_t  mqtt_cfg       = {0};
static bool                      initialized    = false;
static bool                      wifi_connected = false;

// 合并状态 + 新数据标记
static lingxi_state_t            merged_state;
static volatile bool             has_new_data  = false;
static SemaphoreHandle_t         data_mutex    = NULL;

// Topic 前缀长度: "lingxi/v1/" = 10
#define TOPIC_PREFIX "lingxi/v1/"
#define TOPIC_PREFIX_LEN 10

// ========== 工具函数 ==========

/**
 * 从 topic 字符串中确定 type
 * Topic: lingxi/v1/{device_id}/{type}
 * 取第4段 (0-indexed segment 3)
 */
static lingxi_mqtt_type_t resolve_topic_type(const char *topic, int topic_len) {
    if (!topic || topic_len <= 0) return LINGXI_MQTT_TYPE_UNKNOWN;

    // 复制到临时buffer
    char buf[64];
    int len = topic_len < (int)sizeof(buf) - 1 ? topic_len : (int)sizeof(buf) - 1;
    strncpy(buf, topic, len);
    buf[len] = '\0';

    // 跳过 "lingxi/v1/" 前缀
    if (strncmp(buf, TOPIC_PREFIX, TOPIC_PREFIX_LEN) != 0) {
        return LINGXI_MQTT_TYPE_UNKNOWN;
    }

    // 找到第4个斜杠 — 确定 type 段的位置
    // lingxi/v1/{device_id}/{type}
    int slash_count = 0;
    char *p = buf;
    while (*p) {
        if (*p == '/') {
            slash_count++;
            if (slash_count == 3) {
                // p 现在在 device_id 后面的 '/'
                p++;
                // p 指向 type 段
                if (strcmp(p, "sense") == 0)   return LINGXI_MQTT_TYPE_SENSE;
                if (strcmp(p, "energy") == 0)  return LINGXI_MQTT_TYPE_ENERGY;
                if (strcmp(p, "system") == 0)  return LINGXI_MQTT_TYPE_SYSTEM;
                return LINGXI_MQTT_TYPE_UNKNOWN;
            }
        }
        p++;
    }
    return LINGXI_MQTT_TYPE_UNKNOWN;
}

/**
 * 从 topic 中提取 device_id（第3段）
 */
static int extract_device_id(const char *topic, int topic_len, char *out, size_t out_size) {
    if (!topic || topic_len <= 0 || !out || out_size == 0) return -1;

    char buf[128];
    int len = topic_len < (int)sizeof(buf) - 1 ? topic_len : (int)sizeof(buf) - 1;
    strncpy(buf, topic, len);
    buf[len] = '\0';

    // 跳过 "lingxi/v1/" (2个slash)
    if (strncmp(buf, TOPIC_PREFIX, TOPIC_PREFIX_LEN) != 0) return -1;

    char *p = buf + TOPIC_PREFIX_LEN;  // 指向 device_id 开始
    char *end = p;
    while (*end && *end != '/') end++;

    size_t id_len = end - p;
    if (id_len >= out_size) id_len = out_size - 1;
    strncpy(out, p, id_len);
    out[id_len] = '\0';
    return 0;
}

// ========== cJSON 安全取值工具 ==========
static int json_get_int(const cJSON *root, const char *key) {
    cJSON *item = cJSON_GetObjectItem(root, key);
    if (item && cJSON_IsNumber(item)) return item->valueint;
    return 0;
}

static float json_get_float(const cJSON *root, const char *key) {
    cJSON *item = cJSON_GetObjectItem(root, key);
    if (item && cJSON_IsNumber(item)) return (float)item->valuedouble;
    return 0.0f;
}

static const char *json_get_string(const cJSON *root, const char *key) {
    cJSON *item = cJSON_GetObjectItem(root, key);
    if (item && cJSON_IsString(item)) return item->valuestring;
    return NULL;
}

// ========== 按 type 分流解析 ==========

/**
 * 解析 sense topic JSON
 * 期望格式:
 * {
 *   "radar": {"people": 1, "moving": 0},
 *   "env": {"temp": 26.5, "humidity": 62, "light": 350},
 *   "ts": "2026-06-23T14:30:00"
 * }
 */
static void parse_sense(const char *json_str, lingxi_state_t *state) {
    if (!json_str || !state) return;

    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
        ESP_LOGW(TAG, "sense JSON parse error");
        return;
    }

    cJSON *radar = cJSON_GetObjectItem(root, "radar");
    if (radar) {
        state->radar_people = json_get_int(radar, "people");
        state->radar_moving = json_get_int(radar, "moving");
    }

    cJSON *env = cJSON_GetObjectItem(root, "env");
    if (env) {
        state->env_temp     = json_get_float(env, "temp");
        state->env_humidity = json_get_float(env, "humidity");
        // light 可选
        cJSON *light = cJSON_GetObjectItem(env, "light");
        if (light && cJSON_IsNumber(light)) state->env_light = light->valueint;
    }

    const char *ts = json_get_string(root, "ts");
    if (ts) strncpy(state->timestamp, ts, sizeof(state->timestamp) - 1);

    cJSON_Delete(root);
}

/**
 * 解析 energy topic JSON
 * 期望格式:
 * {
 *   "power": {"today_total": 2.3, "current": 450, "voltage": 220, "current_a": 2.1},
 *   "ts": "2026-06-23T14:30:00"
 * }
 */
static void parse_energy(const char *json_str, lingxi_state_t *state) {
    if (!json_str || !state) return;

    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
        ESP_LOGW(TAG, "energy JSON parse error");
        return;
    }

    cJSON *power = cJSON_GetObjectItem(root, "power");
    if (power) {
        state->power_today_total = json_get_float(power, "today_total");
        state->power_current     = json_get_float(power, "current");
        state->power_voltage     = json_get_float(power, "voltage");
        state->power_current_a   = json_get_float(power, "current_a");
    }

    const char *ts = json_get_string(root, "ts");
    if (ts) strncpy(state->timestamp, ts, sizeof(state->timestamp) - 1);

    cJSON_Delete(root);
}

/**
 * 解析 system topic JSON
 * 期望格式:
 * {
 *   "device": {"online": 1, "rssi": -65, "uptime": 86400},
 *   "alarm": {"active": 0, "msg": ""},
 *   "ota": {"version": "1.0.0", "available": 0},
 *   "ts": "2026-06-23T14:30:00"
 * }
 */
static void parse_system(const char *json_str, lingxi_state_t *state) {
    if (!json_str || !state) return;

    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
        ESP_LOGW(TAG, "system JSON parse error");
        return;
    }

    cJSON *device = cJSON_GetObjectItem(root, "device");
    if (device) {
        state->device_online = json_get_int(device, "online");
        state->device_rssi   = json_get_int(device, "rssi");
        state->device_uptime = json_get_int(device, "uptime");
    }

    cJSON *alarm = cJSON_GetObjectItem(root, "alarm");
    if (alarm) {
        state->alarm_active = json_get_int(alarm, "active");
        const char *msg = json_get_string(alarm, "msg");
        if (msg) strncpy(state->alarm_msg, msg, sizeof(state->alarm_msg) - 1);
    }

    cJSON *ota = cJSON_GetObjectItem(root, "ota");
    if (ota) {
        const char *ver = json_get_string(ota, "version");
        if (ver) strncpy(state->ota_version, ver, sizeof(state->ota_version) - 1);
        state->ota_available = json_get_int(ota, "available");
    }

    const char *ts = json_get_string(root, "ts");
    if (ts) strncpy(state->timestamp, ts, sizeof(state->timestamp) - 1);

    cJSON_Delete(root);
}

// ========== MQTT事件回调 ==========
static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                                 int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;

    switch ((esp_mqtt_event_id_t)event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT connected, subscribing to lingxi/v1/+/#");
            // 屏端订阅通配符: lingxi/v1/+/#  (所有设备的所有type)
            // 实际部署时可用具体 device_id 替代 +
            esp_mqtt_client_subscribe(mqtt_client, "lingxi/v1/+/#", 0);
            ESP_LOGI(TAG, "Subscribed to lingxi/v1/+/#");
            break;

        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "MQTT disconnected");
            break;

        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "Subscribe acknowledged, msg_id=%d", event->msg_id);
            break;

        case MQTT_EVENT_DATA: {
            if (event->data_len == 0) break;

            // 确定 topic type
            lingxi_mqtt_type_t type = resolve_topic_type(event->topic, event->topic_len);
            if (type == LINGXI_MQTT_TYPE_UNKNOWN) {
                ESP_LOGW(TAG, "Unknown topic type: %.*s", event->topic_len, event->topic);
                break;
            }

            // 提取 device_id
            char device_id[32] = {0};
            if (event->topic && event->topic_len > 0) {
                extract_device_id(event->topic, event->topic_len, device_id, sizeof(device_id));
            }

            // 复制payload
            int data_len = event->data_len;
            if (data_len > 1023) data_len = 1023;
            char payload[1024];
            strncpy(payload, event->data, data_len);
            payload[data_len] = '\0';

            ESP_LOGI(TAG, "RX type=%s device=%s", 
                     type == LINGXI_MQTT_TYPE_SENSE  ? "sense" :
                     type == LINGXI_MQTT_TYPE_ENERGY ? "energy" : "system",
                     device_id);

            // 线程安全：合并到状态
            if (data_mutex) xSemaphoreTake(data_mutex, portMAX_DELAY);

            // 更新 device_id (只在首次设置)
            if (!merged_state.chip_id[0] && device_id[0]) {
                strncpy(merged_state.chip_id, device_id, sizeof(merged_state.chip_id) - 1);
            }

            // 按 type 分流解析
            switch (type) {
                case LINGXI_MQTT_TYPE_SENSE:
                    parse_sense(payload, &merged_state);
                    ESP_LOGI(TAG, "sense: people=%d, temp=%.1f°C, humidity=%.0f%%",
                             merged_state.radar_people, merged_state.env_temp,
                             merged_state.env_humidity);
                    break;
                case LINGXI_MQTT_TYPE_ENERGY:
                    parse_energy(payload, &merged_state);
                    ESP_LOGI(TAG, "energy: today=%.1fkWh, current=%.0fW",
                             merged_state.power_today_total, merged_state.power_current);
                    break;
                case LINGXI_MQTT_TYPE_SYSTEM:
                    parse_system(payload, &merged_state);
                    ESP_LOGI(TAG, "system: online=%d, alarm=%d, ota_ver=%s",
                             merged_state.device_online, merged_state.alarm_active,
                             merged_state.ota_version);
                    break;
                default:
                    break;
            }

            has_new_data = true;
            if (data_mutex) xSemaphoreGive(data_mutex);

            break;
        }

        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT error");
            break;

        default:
            break;
    }
}

// ========== WiFi连接 ==========
static int wifi_connect(const char *ssid, const char *pass, int timeout_ms) {
    if (!ssid || !*ssid) {
        ESP_LOGE(TAG, "WiFi SSID not configured");
        return -1;
    }

    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);

    ESP_LOGI(TAG, "Connecting to WiFi SSID=%s", ssid);

    int elapsed = 0;
    while (WiFi.status() != WL_CONNECTED && elapsed < timeout_ms) {
        delay(100);
        elapsed += 100;
    }

    if (WiFi.status() == WL_CONNECTED) {
        wifi_connected = true;
        ESP_LOGI(TAG, "WiFi connected. IP: %s", WiFi.localIP().toString().c_str());
        return 0;
    }

    ESP_LOGE(TAG, "WiFi connect timeout (%dms)", timeout_ms);
    return -1;
}

// ========== 公开API实现 ==========

int lingxi_mqtt_init(const lingxi_mqtt_config_t *config) {
    if (!config) return -1;
    if (initialized) {
        ESP_LOGW(TAG, "Already initialized");
        return 0;
    }

    // 创建数据互斥锁
    data_mutex = xSemaphoreCreateMutex();
    if (!data_mutex) {
        ESP_LOGE(TAG, "Failed to create mutex");
        return -1;
    }

    // 初始化合并状态
    memset(&merged_state, 0, sizeof(merged_state));

    // 连接WiFi（最多15秒超时）
    if (wifi_connect(config->wifi_ssid, config->wifi_pass, 15000) != 0) {
        ESP_LOGW(TAG, "WiFi not connected, MQTT will auto-connect when WiFi is up");
    }

    // 配置MQTT
    memset(&mqtt_cfg, 0, sizeof(mqtt_cfg));
    mqtt_cfg.broker.address.hostname = config->mqtt_broker_host;
    mqtt_cfg.broker.address.port     = config->mqtt_broker_port;
    mqtt_cfg.credentials.client_id   = config->mqtt_client_id;
    mqtt_cfg.session.keepalive       = config->mqtt_keepalive > 0 ? config->mqtt_keepalive : 30;
    mqtt_cfg.buffer.size             = 2048;

    // 事件回调
    mqtt_cfg.events = mqtt_event_handler;

    // 创建客户端
    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    if (!mqtt_client) {
        ESP_LOGE(TAG, "Failed to create MQTT client");
        if (data_mutex) vSemaphoreDelete(data_mutex);
        data_mutex = NULL;
        return -1;
    }

    // 启动
    esp_err_t err = esp_mqtt_client_start(mqtt_client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start MQTT client: %s", esp_err_to_name(err));
        esp_mqtt_client_destroy(mqtt_client);
        mqtt_client = NULL;
        if (data_mutex) vSemaphoreDelete(data_mutex);
        data_mutex = NULL;
        return -1;
    }

    initialized = true;
    ESP_LOGI(TAG, "Lingxi MQTT v2 initialized (broker=%s:%d, client=%s)",
             config->mqtt_broker_host, config->mqtt_broker_port, config->mqtt_client_id);
    return 0;
}

int lingxi_mqtt_get_state(lingxi_state_t *out) {
    if (!out || !initialized) return -1;

    if (data_mutex) xSemaphoreTake(data_mutex, portMAX_DELAY);
    if (!has_new_data) {
        if (data_mutex) xSemaphoreGive(data_mutex);
        return 1;  // 无新数据
    }
    memcpy(out, &merged_state, sizeof(lingxi_state_t));
    has_new_data = false;
    if (data_mutex) xSemaphoreGive(data_mutex);
    return 0;  // 有新数据
}

void lingxi_mqtt_loop(void) {
    if (!initialized) return;

    // 检查WiFi状态，断开时尝试重连
    if (WiFi.status() != WL_CONNECTED && wifi_connected) {
        ESP_LOGW(TAG, "WiFi lost, reconnecting...");
        wifi_connected = false;
        WiFi.reconnect();
    } else if (WiFi.status() == WL_CONNECTED && !wifi_connected) {
        wifi_connected = true;
        ESP_LOGI(TAG, "WiFi reconnected. IP: %s", WiFi.localIP().toString().c_str());
    }

    // 消费新数据 → 更新屏幕UI
    // 放在主循环中调用保证LVGL线程安全
    lingxi_state_t state;
    if (lingxi_mqtt_get_state(&state) == 0) {
        int occupied = state.radar_people > 0 ? 1 : 0;

        const char *alarm_msg = state.alarm_active ? state.alarm_msg : NULL;

        // 时间显示
        char time_buf[32] = {0};
        if (state.timestamp[0]) {
            const char *t = strchr(state.timestamp, 'T');
            if (t) {
                t++;
                strncpy(time_buf, t, 5);
                time_buf[5] = '\0';
            } else {
                strncpy(time_buf, state.timestamp, sizeof(time_buf) - 1);
            }
        } else {
            strcpy(time_buf, "--:--");
        }

        // 调用 LVGL UI 更新
        // room_no 和 hotel 保留当前值（屏绑定固定房间）
        lingxi_room_ui_update(
            NULL,                // room_no - 保持现有
            NULL,                // hotel   - 保持现有
            occupied,            // occupied
            state.power_today_total, // eco_kwh
            0,                   // eco_pct - 暂不计算节能率
            state.env_temp,      // temp_c
            (int)state.env_humidity, // humidity
            state.alarm_active,  // alarm
            alarm_msg,           // alarm_msg
            time_buf             // time_str
        );

        ESP_LOGI(TAG, "UI updated: people=%d, temp=%.1f°C, today=%.1fkWh, alarm=%d",
                 state.radar_people, state.env_temp,
                 state.power_today_total, state.alarm_active);
    }
}

int lingxi_mqtt_is_connected(void) {
    if (!initialized || !mqtt_client) return 0;
    return esp_mqtt_client_is_connected(mqtt_client) ? 1 : 0;
}

void lingxi_mqtt_deinit(void) {
    if (!initialized) return;

    if (mqtt_client) {
        esp_mqtt_client_stop(mqtt_client);
        esp_mqtt_client_destroy(mqtt_client);
        mqtt_client = NULL;
    }

    if (data_mutex) {
        vSemaphoreDelete(data_mutex);
        data_mutex = NULL;
    }

    WiFi.disconnect(true);
    wifi_connected = false;
    initialized = false;
    has_new_data = false;

    ESP_LOGI(TAG, "MQTT deinitialized");
}
