// 灵犀MQTT — 屏幕专用空桩
// 编译时未启用MQTT时使用, 仅提供空的loop函数

#ifndef LINGXI_MQTT_H
#define LINGXI_MQTT_H

typedef struct {
    const char *wifi_ssid;
    const char *wifi_pass;
    const char *mqtt_broker_host;
    int         mqtt_broker_port;
    const char *mqtt_client_id;
    int         mqtt_keepalive;
} lingxi_mqtt_config_t;

static inline int lingxi_mqtt_init(lingxi_mqtt_config_t *cfg) { return 0; }
static inline void lingxi_mqtt_loop(void) {}

#endif
