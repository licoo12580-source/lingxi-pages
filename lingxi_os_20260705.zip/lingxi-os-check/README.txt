灵犀操作系统 Lingxi OS

01_constitution/ — 定义灵犀是谁
02_skills/       — 定义灵犀能做什么
03_runtime/      — 保证做事时不忘记自己是谁
04_engineering/  — 把宪法落到真实系统
05_products/     — 把系统变成商业价值
06_audit/        — 证明这一切没有漂移
07_scripts/      — 工具与自动化

版本：v1.2 | 状态：冻结 | 仓库：私有
