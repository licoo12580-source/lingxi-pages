// FT6336U.cpp — 电容触摸屏驱动 (软件I2C bit-bang版)
// 不用ESP32硬件I2C(Wire)，用GPIO模拟I2C（跟厂家STC32 demo一样）
#include "FT6336U.h"

FT6336U::FT6336U() {}

// 微秒级延时 (用于I2C时序)
static inline void i2c_delay() {
    delayMicroseconds(5);
}

// 初始化GPIO
static void gpio_init(int sda, int scl) {
    pinMode(sda, OUTPUT_OPEN_DRAIN);
    pinMode(scl, OUTPUT_OPEN_DRAIN);
    digitalWrite(sda, HIGH);
    digitalWrite(scl, HIGH);
    i2c_delay();
}

// I2C START: SCL高时SDA从高→低
static void i2c_start(int sda, int scl) {
    digitalWrite(sda, HIGH);
    digitalWrite(scl, HIGH);
    i2c_delay();
    digitalWrite(sda, LOW);
    i2c_delay();
    digitalWrite(scl, LOW);
}

// I2C STOP: SCL高时SDA从低→高
static void i2c_stop(int sda, int scl) {
    digitalWrite(sda, LOW);
    digitalWrite(scl, HIGH);
    i2c_delay();
    digitalWrite(sda, HIGH);
    i2c_delay();
}

// 发送一字节，返回ACK (0=ACK, 1=NACK)
static bool i2c_write_byte(int sda, int scl, uint8_t data) {
    for (int i = 0; i < 8; i++) {
        digitalWrite(sda, (data & 0x80) ? HIGH : LOW);
        data <<= 1;
        digitalWrite(scl, HIGH);
        i2c_delay();
        digitalWrite(scl, LOW);
        i2c_delay();
    }
    // 释放SDA，等待ACK
    pinMode(sda, INPUT);
    digitalWrite(scl, HIGH);
    i2c_delay();
    bool ack = (digitalRead(sda) == LOW);
    digitalWrite(scl, LOW);
    pinMode(sda, OUTPUT_OPEN_DRAIN);
    return ack;  // true=ACK, false=NACK
}

// 读取一字节，发送ACK/NAK
static uint8_t i2c_read_byte(int sda, int scl, bool send_ack) {
    uint8_t data = 0;
    pinMode(sda, INPUT);
    for (int i = 0; i < 8; i++) {
        data <<= 1;
        digitalWrite(scl, HIGH);
        i2c_delay();
        if (digitalRead(sda)) data |= 1;
        digitalWrite(scl, LOW);
        i2c_delay();
    }
    pinMode(sda, OUTPUT_OPEN_DRAIN);
    digitalWrite(sda, send_ack ? LOW : HIGH);
    digitalWrite(scl, HIGH);
    i2c_delay();
    digitalWrite(scl, LOW);
    digitalWrite(sda, HIGH);
    return data;
}

// 读写寄存器 (bit-bang实现)
static bool bb_read_regs(int sda, int scl, uint8_t addr, uint8_t reg, uint8_t *buf, uint8_t len) {
    i2c_start(sda, scl);
    // 写地址+寄存器
    if (!i2c_write_byte(sda, scl, addr << 1)) {  // 写方向
        i2c_stop(sda, scl);
        return false;
    }
    if (!i2c_write_byte(sda, scl, reg)) {
        i2c_stop(sda, scl);
        return false;
    }
    // 重启 + 读
    i2c_start(sda, scl);
    if (!i2c_write_byte(sda, scl, (addr << 1) | 1)) {  // 读方向
        i2c_stop(sda, scl);
        return false;
    }
    for (uint8_t i = 0; i < len; i++) {
        buf[i] = i2c_read_byte(sda, scl, (i < len - 1));
    }
    i2c_stop(sda, scl);
    return true;
}

static bool bb_write_reg(int sda, int scl, uint8_t addr, uint8_t reg, uint8_t val) {
    i2c_start(sda, scl);
    if (!i2c_write_byte(sda, scl, addr << 1)) {
        i2c_stop(sda, scl);
        return false;
    }
    if (!i2c_write_byte(sda, scl, reg)) {
        i2c_stop(sda, scl);
        return false;
    }
    i2c_write_byte(sda, scl, val);  // 写数据，不管ACK
    i2c_stop(sda, scl);
    return true;
}

// ====== FT6336U 驱动接口 ======

int _sda = FT6336U_SDA;
int _scl = FT6336U_SCL;

bool FT6336U::begin(int sda, int scl) {
    if (sda >= 0 && scl >= 0) {
        _sda = sda;
        _scl = scl;
    }
    
    // GPIO初始化 (开漏输出)
    gpio_init(_sda, _scl);
    
    // RST: 20ms LOW → 300ms HIGH (厂家时序)
    pinMode(FT6336U_RST, OUTPUT);
    digitalWrite(FT6336U_RST, LOW);
    delay(20);
    digitalWrite(FT6336U_RST, HIGH);
    delay(300);
    
    pinMode(FT6336U_INT, INPUT_PULLUP);
    
    // 尝试读取芯片ID
    uint8_t id_a8 = 0xFF, id_a3 = 0xFF;
    bb_read_regs(_sda, _scl, FT6336U_ADDR, 0xA8, &id_a8, 1);
    bb_read_regs(_sda, _scl, FT6336U_ADDR, 0xA3, &id_a3, 1);
    Serial.printf("[Touch] ID_A8=0x%02X ID_A3=0x%02X\n", id_a8, id_a3);
    
    // 设置中断模式
    bb_write_reg(_sda, _scl, FT6336U_ADDR, REG_G_MODE, 0x01);
    bb_write_reg(_sda, _scl, FT6336U_ADDR, REG_DEVICE_MODE, 0x00);
    
    bool ok = (id_a8 != 0xFF && id_a3 != 0xFF);
    Serial.printf("[Touch] %s\n", ok ? "OK" : "FAIL (chip not responding)");
    return ok;
}

void FT6336U::reset() {
    pinMode(FT6336U_RST, OUTPUT);
    digitalWrite(FT6336U_RST, LOW);
    delay(20);
    digitalWrite(FT6336U_RST, HIGH);
    delay(300);
}

uint8_t FT6336U::readReg8(uint8_t reg) {
    uint8_t val = 0xFF;
    bb_read_regs(_sda, _scl, FT6336U_ADDR, reg, &val, 1);
    return val;
}

bool FT6336U::readRegs(uint8_t reg, uint8_t *buf, uint8_t len) {
    return bb_read_regs(_sda, _scl, FT6336U_ADDR, reg, buf, len);
}

void FT6336U::writeReg8(uint8_t reg, uint8_t val) {
    bb_write_reg(_sda, _scl, FT6336U_ADDR, reg, val);
}

uint8_t FT6336U::touchCount() {
    uint8_t td = readReg8(REG_TD_STATUS);
    if (td == 0xFF) return 0;
    return td & 0x0F;
}

bool FT6336U::getPoint(uint16_t &x, uint16_t &y) {
    uint8_t buf[4] = {0};
    if (!readRegs(REG_P1_XH, buf, 4)) return false;
    uint8_t evt = (buf[0] >> 6) & 0x03;
    if (evt == 0 || evt == 2) {
        x = ((uint16_t)(buf[0] & 0x0F) << 8) | buf[1];
        y = ((uint16_t)(buf[2] & 0x0F) << 8) | buf[3];
        return true;
    }
    return false;
}

TScan FT6336U::scan() {
    TScan data = {0};
    uint8_t td = readReg8(REG_TD_STATUS);
    if (td == 0xFF) return data;
    data.count = td & 0x0F;
    data.gesture = readReg8(REG_GESTURE_ID);
    for (uint8_t i = 0; i < data.count && i < 2; i++) {
        uint8_t buf[4];
        if (readRegs(REG_P1_XH + i * 6, buf, 4)) {
            data.pts[i].event = (TouchEvt)((buf[0] >> 6) & 0x03);
            data.pts[i].x = ((uint16_t)(buf[0] & 0x0F) << 8) | buf[1];
            data.pts[i].y = ((uint16_t)(buf[2] & 0x0F) << 8) | buf[3];
        }
    }
    return data;
}

bool FT6336U::isTouched() { return touchCount() > 0; }

bool FT6336U::waitRelease(uint32_t timeout_ms) {
    uint32_t start = millis();
    while (millis() - start < timeout_ms) {
        if (!isTouched()) return true;
        delay(10);
    }
    return false;
}
