灵犀固件版本存档 - 供AI审核用
======================================

仓库: github.com/licoo12580-source/lingxi
硬件: HW-678A N16R8 (ESP32-S3, 16MB Flash, 8MB PSRAM)
屏:   4寸 ILI9488 480x320 (SPI: CS=45, DC=47, RST=48, MOSI=21, SCK=20)
       3.2寸 ILI9341 320x240 (同样引脚)
LED:  WS2812 @ GPIO48
触摸: FT6336U (I2C: SDA=35, SCL=36)
雷达: MS24 (UART: TX=38, RX=39)
背光: 3.3V直接供电 (不经过GPIO)

版本列表:
  v0310A - ILI9341诊断固件, 唯一验证可启动版本 [源码完整]
  v0310D - ILI9488 + FT6336U触摸 + 20个UI页面 + 滑动翻页 [源码丢失,仅描述]
  v0311A - ILI9488最小化亮屏测试 [源码丢失,已重建]
  v0312B - ILI9488最小化测试(DIO 40MHz, USE_HSPI_PORT) [源码完整]

烧录方式:
  esptool --chip esp32s3 write_flash 0x0 <固件文件>

每版本内容:
  文件名        说明
  <.bin>        合并固件(bootloader+分区表+应用), 地址0x0烧录
  *-source.txt  对应源文件(test_all.cpp + platformio.ini + User_Setup.h)

环境配置说明 (platformio.ini):
  board = esp32-s3-devkitc-1
  flash_mode = dio
  flash_freq = 40m
  psram = disable
  usb_mode = 0
  USE_HSPI_PORT  (TFT_eSPI使用HSPI而不是默认SPI)
